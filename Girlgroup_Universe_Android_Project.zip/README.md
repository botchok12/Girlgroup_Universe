# Girlgroup Universe Android wrapper
Native Android WebView app embedding the current Girlgroup Universe HTML locally. Data uses WebView localStorage on-device.

## Build APK
This repository includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
Upload/push this project to a GitHub repository, then Actions → Build Android APK → Run workflow.
Download `Girlgroup-Universe-debug-apk` from the run's Artifacts. Install the APK on Android (allow install from this source if prompted).

This source package is not itself an APK; APK compilation requires Android SDK/Gradle, which are not available in this execution environment.
